/* =============================================
   NÍTIDLY — main.js v2
   Sin dependencias externas.
   ============================================= */

const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// ─── Nav scroll effect ──────────────────────
const nav = document.getElementById('nav');
if (nav) {
  const onScroll = () => nav.classList.toggle('scrolled', window.scrollY > 20);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

// ─── Mobile nav toggle ──────────────────────
const navToggle = document.getElementById('nav-toggle');
const navMobile = document.getElementById('nav-mobile');

if (navToggle && navMobile) {
  const closeMenu = () => {
    navMobile.classList.remove('open');
    navToggle.setAttribute('aria-expanded', 'false');
  };
  navToggle.addEventListener('click', () => {
    const isOpen = navMobile.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', String(isOpen));
  });
  navMobile.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
  document.addEventListener('click', (e) => {
    if (!nav.contains(e.target) && !navMobile.contains(e.target)) closeMenu();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeMenu(); });
}

// ─── Firma: el titular "enfoca" palabra a palabra ───
const heroWords = document.querySelectorAll('.hero__title .hw');
if (heroWords.length) {
  if (reducedMotion) {
    heroWords.forEach(w => w.classList.add('visible'));
  } else {
    heroWords.forEach((word, i) => {
      setTimeout(() => word.classList.add('visible'), 250 + i * 110);
    });
  }
}

// ─── Scroll reveal (IntersectionObserver) ───
const revealEls = document.querySelectorAll('.reveal');
if (revealEls.length) {
  if (reducedMotion || !('IntersectionObserver' in window)) {
    revealEls.forEach(el => el.classList.add('visible'));
  } else {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    revealEls.forEach(el => io.observe(el));
  }
}

// ─── Smooth anchor scrolling ────────────────
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', (e) => {
    const target = document.querySelector(anchor.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const navH = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--nav-h'), 10) || 72;
      const top = target.getBoundingClientRect().top + window.scrollY - navH - 20;
      window.scrollTo({ top, behavior: reducedMotion ? 'auto' : 'smooth' });
    }
  });
});

// ─── Formulario de contacto ─────────────────
const contactForm = document.getElementById('contact-form');
const formSuccess = document.getElementById('form-success');

if (contactForm && formSuccess) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const btn = contactForm.querySelector('.form-submit');
    const originalText = btn.textContent;

    const required = contactForm.querySelectorAll('[required]');
    let valid = true;
    let firstInvalid = null;

    required.forEach(field => {
      if (field.type === 'checkbox') {
        field.closest('.form-checkbox')?.classList.remove('invalid');
        if (!field.checked) {
          field.closest('.form-checkbox')?.classList.add('invalid');
          valid = false;
          firstInvalid = firstInvalid || field;
        }
        return;
      }
      field.style.borderColor = '';
      if (!field.value.trim()) {
        field.style.borderColor = 'rgba(255, 80, 80, 0.5)';
        valid = false;
        firstInvalid = firstInvalid || field;
      }
    });

    if (!valid) { firstInvalid?.focus(); return; }

    btn.disabled = true;
    btn.textContent = 'Enviando...';
    btn.style.opacity = '0.7';

    try {
      const response = await fetch('https://formspree.io/f/xvzwvylp', {
        method: 'POST',
        body: new FormData(contactForm),
        headers: { 'Accept': 'application/json' }
      });

      if (response.ok) {
        contactForm.style.display = 'none';
        formSuccess.classList.add('show');
        formSuccess.focus?.();
      } else {
        throw new Error('server');
      }
    } catch {
      btn.disabled = false;
      btn.textContent = originalText;
      btn.style.opacity = '';
      alert('No se ha podido enviar el mensaje. Inténtalo de nuevo o escribe directamente a ana@nitidly.com');
    }
  });

  contactForm.querySelectorAll('.form-input, .form-select, .form-textarea').forEach(field => {
    field.addEventListener('input', () => { field.style.borderColor = ''; });
  });
  contactForm.querySelectorAll('input[type="checkbox"]').forEach(field => {
    field.addEventListener('change', () => {
      field.closest('.form-checkbox')?.classList.remove('invalid');
    });
  });
}
